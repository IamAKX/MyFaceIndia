<?php
	define('HOST','localhost');
	define('USER','myfaclpm_mfi');
	define('PASS','Myface@543210');
	define('DB','myfaclpm_mfi');
	
	$conn = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

